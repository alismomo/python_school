###Tips Suggestion for Restaurant. Alisa Dzhoha. The purpose of this program is to calculate fifteen and twenty percent tip based on the user's input and calculate total with the tip. Date: 09/02/2025

bill = float(input("Enter the total from a bill for dinner: "))
fifteen_tip, twenty_tip = 0.15, 0.20
fifteen_tip = bill * fifteen_tip
twenty_tip = bill * twenty_tip
print(f"Suggested tip: 15% tip = ${fifteen_tip}, 20% tip = ${twenty_tip}")
print(f"Your total with 15% tip: ${bill + fifteen_tip}. Your total with 20% tip: ${bill + twenty_tip}")