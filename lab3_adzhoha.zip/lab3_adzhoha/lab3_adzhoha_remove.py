###Addition of the items to the list. Alisa Dzhoha. This program takes a list from imported file lab3_adzhoha_replace and remove item "binoculars" from the list
from lab3_adzhoha_replace import camping_items 

camping_items.remove("binoculars")
print(camping_items)







