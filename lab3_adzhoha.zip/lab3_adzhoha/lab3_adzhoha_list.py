###List creation. Alisa Dzhoha. This program includes a list, prints out the length of the list, and displays items of the list in sorted order.
camping_items = ["tent poles", "tent", "utensils", "water bottle", "backpack", "first aid", "towel", "pillow", "blanket", "cups" ]
print("The length of the list is:", len(camping_items))
camping_items.sort()
print(camping_items)


  