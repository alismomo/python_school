###Replacement of the item to the list. Alisa Dzhoha. This program takes a list from imported file lab3_adzhoha_add and replaces the last itam with a new item
from lab3_adzhoha_add import *

camping_items[-1] = "binoculars"

print(camping_items)