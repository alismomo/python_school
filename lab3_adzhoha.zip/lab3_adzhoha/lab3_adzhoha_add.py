###Addition of the items to the list. Alisa Dzhoha. This program takes a list from imported file lab3_adzhoha_list and adds 5 items to it
from lab3_adzhoha_list import *

additional_items = ["sunscreen", "toilet paper", "shampoo", "conditioner", "sunglasses"]
camping_items.extend(additional_items)
print(camping_items)
